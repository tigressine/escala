java -cp .:libs/ escala.Escala
