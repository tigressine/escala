java -cp .:libs/derby.jar escala.Escala
