
package escala.structures;

public class Player {

}
